/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.group11.configs;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

/**
 *
 * @author pminh
 */
public class SpringSecurityWebAppInitializer extends AbstractSecurityWebApplicationInitializer{
    
}
